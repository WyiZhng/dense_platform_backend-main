import unittest
from ..utils import makeAccountJwt, resolveAccountJwt


# TODO:这里编写一下 utils 下jwt模块的测试用例
# 简单做一下就行
class TestJwt(unittest.TestCase):
    pass
