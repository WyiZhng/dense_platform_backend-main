# TODO:这里需要编写Api的自动化测试,可以查阅 https://fastapi.tiangolo.com/zh/tutorial/testing/ 了解如何设计api自动化测试
# TODO:编写一些工具类的自动化测试
