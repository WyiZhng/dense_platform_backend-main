from datetime import date
import typing
import asyncio
from fastapi import APIRouter, File, UploadFile,HTTPException
from pydantic import BaseModel, ConfigDict
from dense_platform_backend_main.database.api import teechLevel
from dense_platform_backend_main.database.table import ImageType, ReportStatus
from dense_platform_backend_main.database.storage import (
    save_report, load_report, get_user_reports,
    save_comment, get_report_comments,
    save_report_image, get_report_images,
    delete_report,save_report_com
)
from dense_platform_backend_main.utils.request import TokenRequest
from dense_platform_backend_main.utils.response import Response
from dense_platform_backend_main.utils import resolveAccountJwt
from fastapi.responses import FileResponse
import cv2
import numpy as np
from dense_platform_backend_main.algorithm.predict_class import predict

router = APIRouter()

class ReportRequest(BaseModel):
    token: str
    doctor: str
    images: typing.List[str]

@router.post("/algorithm/predict")
async def predict_image(request: ReportRequest):  # 接受一个图片文件输入

    async def process_images():
        img_path = f"storage/images/{request.images[0]}.jpg"  # 假设图片存储路径

        # 读取图片并转换为字节流
        with open(img_path, 'rb') as img_file:
            contents = img_file.read()
        image_np = np.asarray(bytearray(contents), dtype=np.uint8)

        img = cv2.imdecode(image_np, cv2.IMREAD_COLOR)
        try:
            data_json, image_id = predict(img)  # 预测过程，将所需数据保存并返回（这里可以保存到数据库）
        except Exception as e:
            print(e)
        diag = teechLevel(str(data_json))
        username = resolveAccountJwt(request.token)["account"]
        report_data = {
            "user": username,
            "doctor": request.doctor,
            "submitTime": str(date.today()),
            "current_status": ReportStatus.Completed,
            "images": request.images,
            "diagnose": diag,
            "Result_img": image_id
        }
        save_report_com(report_data)
        delete_report(report_id)

    # 启动异步任务
    asyncio.create_task(process_images())

    username = resolveAccountJwt(request.token)["account"]
    report_data = {
        "user": username,
        "doctor": request.doctor,
        "submitTime": str(date.today()),
        "current_status": ReportStatus.Checking,
        "images": request.images,
        "diagnose": "",
        "Result_img": ""
    }
    report_id = save_report(report_data)

    return Response()


# @router.post("/api/submitReport")
# async def submitReport(request: ReportRequest):
#     username = resolveAccountJwt(request.token)["account"]
#
#     report_data = {
#         "user": username,
#         "doctor": request.doctor,
#         "submitTime": str(date.today()),
#         "current_status": ReportStatus.Checking,
#         "images": request.images,
#         "diagnose": None
#     }
#
#     save_report(report_data)
#     return Response()